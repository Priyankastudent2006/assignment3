package com.example.dailybuddy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class Habit(
    val name: String,
    val description: String
)

class HabitListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_habits_list)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewHabits)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val habits = listOf(
            Habit("Drink Water", "8 glasses"),
            Habit("Walk", "30 minutes")
        )

        recyclerView.adapter = HabitAdapter(habits)
    }
}

class HabitAdapter(private val habits: List<Habit>) :
    RecyclerView.Adapter<HabitAdapter.HabitViewHolder>() {

    class HabitViewHolder(view: TextView) : RecyclerView.ViewHolder(view) {
        val textView: TextView = view
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HabitViewHolder {
        val textView = TextView(parent.context)
        textView.textSize = 18f
        textView.setPadding(20, 20, 20, 20)
        return HabitViewHolder(textView)
    }

    override fun onBindViewHolder(holder: HabitViewHolder, position: Int) {
        val habit = habits[position]
        holder.textView.text = "${habit.name} - ${habit.description}"
    }

    override fun getItemCount(): Int = habits.size
}
